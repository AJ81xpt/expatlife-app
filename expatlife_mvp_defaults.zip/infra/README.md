docker compose up -d --build
